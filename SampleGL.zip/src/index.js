import "./styles.css";
import * as THREE from "three";
import CameraControls from "camera-controls";
import "./WebGl";

//var images = [1, 2, 3, 4, 5, 6, 7, 8, 9];

var images = [1, 2, 3, 4, 5];
var renderer, camera, scene, controls, clock;

var itemsLength = images.length,
  itemPositionZ = 10,
  width = window.innerWidth,
  height = window.innerHeight,
  fieldOfView = 45,
  aspectRatio = width / height,
  NEAR = 1,
  FAR = itemsLength * itemPositionZ + itemPositionZ,
  renderBg = 0xdddddd;

function init(images) {
  renderer = new THREE.WebGLRenderer();
  camera = new THREE.PerspectiveCamera(fieldOfView, aspectRatio, NEAR, FAR);
  scene = new THREE.Scene();
  clock = new THREE.Clock();

  CameraControls.install({ THREE: THREE });

  renderer.setSize(width, height);
  renderer.setClearColor(renderBg);
  document.body.appendChild(renderer.domElement);

  camera.position.set(0, 0, FAR); // Set position like this

  const gridHelper = new THREE.GridHelper(3000, 300);
  gridHelper.position.y = 0;
  scene.add(gridHelper);

  var helper = new THREE.CameraHelper(camera);
  scene.add(helper);

  controls = new CameraControls(camera, renderer.domElement);
  controls.minDistance = NEAR;
  controls.maxDistance = FAR;

  for (let index = 0; index < images.length; index++) {
    var geometry = new THREE.CubeGeometry(2, 2, 1);
    var material = new THREE.MeshBasicMaterial({
      color: new THREE.Color(0xffffff).setHex(Math.random() * 0xffffff)
    });
    var pic = new THREE.Mesh(geometry, material);
    pic.material.side = THREE.DoubleSide;
    var picPositionZ = index * itemPositionZ;
    pic.position.set(getRandomInt(-5, 5), getRandomInt(-5, 5), picPositionZ);
    scene.add(pic);
  }
}
function animate() {
  requestAnimationFrame(animate);
  render();
}

function render() {
  renderer.render(scene, camera);
  var delta = clock.getDelta();
  controls.update(delta);
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

init(images);
animate();
